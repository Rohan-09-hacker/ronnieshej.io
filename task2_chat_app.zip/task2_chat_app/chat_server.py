import socket
import threading

# Server configuration
# '127.0.0.1' is local host, meaning the server runs locally on your machine
HOST = '127.0.0.1'
PORT = 55555

# Lists to track active clients and their associated usernames
clients = []
usernames = []

def broadcast(message, sender_client):
    """Sends a message to all connected clients except the sender."""
    for client in clients:
        if client != sender_client:
            try:
                client.send(message)
            except Exception:
                # If a connection is broken, clear the client out
                remove_client(client)

def remove_client(client):
    """Safely removes a client from our tracking pools if they disconnect."""
    if client in clients:
        index = clients.index(client)
        clients.remove(client)
        client.close()
        username = usernames[index]
        usernames.remove(username)
        broadcast(f"📢 {username} has left the chat.".encode('utf-8'), None)
        print(f"[-] Connection severed with {username}")

def handle_client(client):
    """Continuous loop running on a dedicated thread to listen for data from a specific client."""
    while True:
        try:
            # Receive incoming packet payload (up to 1024 bytes)
            message = client.recv(1024)
            if message:
                broadcast(message, client)
            else:
                remove_client(client)
                break
        except Exception:
            remove_client(client)
            break

def receive_connections():
    """Main loop listening for initial socket handshakes from new clients."""
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((HOST, PORT))
    server.listen()
    
    print(f"🚀 [SERVER ACTIVE] Listening on {HOST}:{PORT}...")

    while True:
        try:
            # Accept a new incoming network handshake
            client, address = server.accept()
            print(f"[+] Secure physical link established with {str(address)}")

            # The client sends their username as the very first packet payload
            client.send("USER_REQ".encode('utf-8'))
            username = client.recv(1024).decode('utf-8')
            
            usernames.append(username)
            clients.append(client)

            print(f"[👤] Identity verified for user: {username}")
            broadcast(f"🎉 {username} joined the workspace channel!".encode('utf-8'), client)
            client.send("Connected to server successfully.".encode('utf-8'))

            # Spin up a dedicated background thread to monitor this specific client's messages
            thread = threading.Thread(target=handle_client, args=(client,))
            thread.start()
        except KeyboardInterrupt:
            print("\nShutting down chat hub server securely.")
            break

if __name__ == "__main__":
    receive_connections()