import socket
import threading
import tkinter as tk
from tkinter import simpledialog, messagebox

# Server connection details (matching our server)
HOST = '127.0.0.1'
PORT = 55555

class ChatClient:
    def __init__(self, root):
        self.root = root  # Established gracefully for error destruction handle
        self.root.title("Pinnacle Secure Chat Link")
        self.root.geometry("450x600")
        self.root.configure(bg="#1e1e2e")  # Matching dark mode aesthetic

        # Prompt for Username using a secure pop-up dialog
        self.username = simpledialog.askstring("Profile Setup", "Enter your username/handle:", parent=root)
        if not self.username:
            self.username = "Anonymous"

        # --- Network Connection Initialization ---
        self.client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            self.client_socket.connect((HOST, PORT))
        except Exception as e:
            messagebox.showerror("Connection Error", f"Could not connect to the chat server: {e}")
            self.root.destroy()
            return

        # --- UI Component Generation ---
        # Chat Header Label
        self.header_label = tk.Label(
            root, 
            text=f"💬 GLOBAL CHANNEL (User: {self.username})", 
            font=("Helvetica", 12, "bold"), 
            fg="#89b4fa", 
            bg="#1e1e2e"
        )
        self.header_label.pack(pady=10)

        # Message Display Log Panel (Created ONCE and configured with tags)
        self.text_area = tk.Text(
            root, 
            bg="#313244", 
            fg="#cdd6f4", 
            font=("Helvetica", 11), 
            state='disabled', 
            wrap='word',
            bd=0,
            highlightthickness=1,
            highlightbackground="#45475a"
        )
        self.text_area.pack(padx=15, pady=5, fill='both', expand=True)

        # Configure Custom Text Color Tags
        self.text_area.tag_config("self_msg", foreground="#a6e3a1")   # Vibrant Green for you
        self.text_area.tag_config("other_msg", foreground="#cdd6f4")  # Clean Silver/White for others
        self.text_area.tag_config("system_msg", foreground="#89b4fa") # Blue for alerts/joins

        # Bottom Input Bar Container Frame
        self.input_frame = tk.Frame(root, bg="#1e1e2e")
        self.input_frame.pack(padx=15, pady=15, fill='x')

        # Entry Message Field
        self.msg_entry = tk.Entry(
            self.input_frame, 
            font=("Helvetica", 12), 
            bg="#313244", 
            fg="#cdd6f4", 
            insertbackground="#cdd6f4",
            bd=0,
            highlightthickness=1,
            highlightbackground="#45475a"
        )
        self.msg_entry.pack(side='left', fill='x', expand=True, ipady=6, padx=(0, 10))
        self.msg_entry.bind("<Return>", lambda event: self.send_message())

        # Send Button Action
        self.send_button = tk.Button(
            self.input_frame, 
            text="Send", 
            font=("Helvetica", 10, "bold"), 
            bg="#a6e3a1", 
            fg="#11111b", 
            bd=0,
            command=self.send_message
        )
        self.send_button.pack(side='right', ipady=5, ipadx=15)

        # --- Multithreading Setup for Background Listening ---
        self.receive_thread = threading.Thread(target=self.receive_messages)
        self.receive_thread.daemon = True  # Ensures thread dies when GUI window closes
        self.receive_thread.start()

    def display_message(self, message, tag_type="other_msg"):
        """Safely appends a message line into the log panel with a specific color tag."""
        self.text_area.config(state='normal')
        
        # Check if it's a join/leave alert to format it as a system message
        if "joined" in message or "left" in message or "Connected" in message:
            tag_type = "system_msg"
            
        self.text_area.insert(tk.END, message + "\n", tag_type)
        self.text_area.config(state='disabled')
        self.text_area.yview(tk.END)  # Autoscroll down

    def send_message(self):
        """Grabs text input and pushes it through the socket connection pipeline."""
        message_text = self.msg_entry.get().strip()
        if message_text:
            formatted_msg = f"[{self.username}]: {message_text}"
            try:
                self.client_socket.send(formatted_msg.encode('utf-8'))
                self.display_message(f"[You]: {message_text}", "self_msg")
                self.msg_entry.delete(0, tk.END)
            except Exception:
                self.display_message("❌ Connection link severed. Unable to transmit.", "other_msg")

    def receive_messages(self):
        """Continuous background daemon loop listening for incoming broadcast buffers from server."""
        while True:
            try:
                message = self.client_socket.recv(1024).decode('utf-8')
                if message == "USER_REQ":
                    self.client_socket.send(self.username.encode('utf-8'))
                else:
                    self.display_message(message, "other_msg")
            except Exception:
                break

if __name__ == "__main__":
    root = tk.Tk()
    app = ChatClient(root)
    root.mainloop()